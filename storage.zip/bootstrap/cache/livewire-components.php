<?php return array (
  'cart-area' => 'App\\Http\\Livewire\\CartArea',
  'client' => 'App\\Http\\Livewire\\Client',
  'gellery-listing' => 'App\\Http\\Livewire\\GelleryListing',
  'home' => 'App\\Http\\Livewire\\Home',
  'navbar' => 'App\\Http\\Livewire\\Navbar',
  'products.products-listing' => 'App\\Http\\Livewire\\Products\\ProductsListing',
  'products.single-product' => 'App\\Http\\Livewire\\Products\\SingleProduct',
);