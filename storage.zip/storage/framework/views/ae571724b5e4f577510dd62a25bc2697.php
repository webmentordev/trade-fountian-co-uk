<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['message']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['message']); ?>
<?php foreach (array_filter((['message']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="bg-black flex items-center py-5 px-6 font-semibold text-lg fixed bottom-3 left-3 rounded-lg text-white">
    <img src="https://api.iconify.design/material-symbols:check-circle-outline-rounded.svg?color=%2337d82c" alt="Check Icon" width="30"> 
    <p class="ml-4"><?php echo e($message); ?></p>
</div><?php /**PATH E:\Laravel\fountain\resources\views/components/alerts/success.blade.php ENDPATH**/ ?>