<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['review']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['review']); ?>
<?php foreach (array_filter((['review']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="flex flex-col h-fit w-full p-6 bg-white transition-all hover:shadow-xl border border-gray-200 rounded-xl">
    <div class="flex items-center mb-1">
        <div class="w-[30px] h-[30px] rounded-full bg-center bg-cover" style="background-image: url('https://images-eu.ssl-images-amazon.com/images/S/amazon-avatars-global/default._CR0,0,1024,1024_SX48_.png')"></div>
        <span class="ml-3 text-sm text-slate-600"><?php echo e($review->name); ?></span>
    </div>
    <div class="flex items-center mb-1">
        <ul class="flex">
            <li><img width="20px" src="https://api.iconify.design/material-symbols:star.svg?color=%23FFA41C" alt="Review star"></li>
            <li><img width="20px" src="https://api.iconify.design/material-symbols:star.svg?color=%23FFA41C" alt="Review star"></li>
            <li><img width="20px" src="https://api.iconify.design/material-symbols:star.svg?color=%23FFA41C" alt="Review star"></li>
            <li><img width="20px" src="https://api.iconify.design/material-symbols:star.svg?color=%23FFA41C" alt="Review star"></li>
            <?php if($review->star > 4.5): ?>
                <li><img width="20px" src="https://api.iconify.design/material-symbols:star.svg?color=%23FFA41C" alt="Review star"></li>
            <?php else: ?>
                <li><img width="20px" src="https://api.iconify.design/material-symbols:star-half.svg?color=%23FFA41C" alt="Review star"></li>
            <?php endif; ?>
        </ul>
        <p class="text-[15px] ml-2 mt-1"><b><?php echo e($review->title); ?></b></p>
    </div>
    <div class="flex items-center text-[14px] mb-1">
        <p class="text-slate-500">Colour Name: <?php echo e($review->color); ?> | </p>
        <p class="text-[#c45500] ml-1"><b> Verified Purchase</b></p>
    </div>
    <p class="text-slate-700 text-[14px] mb-2">Reviewd in the <?php echo e($review->location); ?> on <?php echo e($review->date); ?></p>
    <p class="text-[15px] mb-3"><?php echo e($review->review); ?></p>
    <a href="<?php echo e($review->url); ?>" class="text-sm w-fit font-semibold inline-block py-2 px-5 rounded-lg bg-[#FFA41C]" target="_blank" rel="nofollow">Read</a>
</div><?php /**PATH E:\Laravel\fountain\resources\views/components/review.blade.php ENDPATH**/ ?>