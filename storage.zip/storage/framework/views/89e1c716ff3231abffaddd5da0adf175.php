
<?php $__env->startSection('content'); ?>
    <section class="w-full">
        <div class="max-w-6xl m-auto py-12 px-4 w-full" id="products">
            <div class="text-center mb-4">
                <h2 class="text-5xl title mb-2">Trade Fountain products</h2>
                <p>Here is the listing of all our products that wehave to offer</p>
            </div>
            <?php if(count($products)): ?>
                <div class="grid grid-cols-3 gap-6 970:grid-cols-3 785px:grid-cols-2 460px:grid-cols-1">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('single.product', $product->slug)); ?>" class="w-full flex flex-col group">
                            <div class="flex items-center justify-center bg-white rounded-lg overflow-hidden h-[400px] mb-3">
                                
                                <img data-src="<?php echo e(asset('/storage/'. $product->image)); ?>" class="w-[70%] 460px:w-[50%] lazyload" title="<?php echo e($product->name); ?>" alt="<?php echo e($product->name); ?> Image">
                            </div>
                            <h3><?php echo e($product->short_name); ?></h3>
                            <span class="price font-semibold text-gray-500 transition-all">£<?php echo e($product->price); ?> GBP</span>
                            <div class="py-3 items-center px-4 mt-3 bg-black rounded-lg text-white transition-all">
                                <div class="flex items-center justify-center">
                                    <img src="https://api.iconify.design/material-symbols:expand-circle-right.svg?color=%23fff" class="mr-2" alt="Cart Icon" width="23"> Buy Now
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\fountain\resources\views/products.blade.php ENDPATH**/ ?>