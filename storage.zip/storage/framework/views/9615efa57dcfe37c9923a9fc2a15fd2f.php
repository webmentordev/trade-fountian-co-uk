 <?php $__env->slot('header', null, []); ?> 
    <div class="flex items-center justify-between">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Products')); ?>

        </h2>
        <a href="<?php echo e(route('create.product')); ?>" class="py-2 px-4 rounded-md bg-indigo-600 text-white font-semibold">Create Product</a>
    </div>
 <?php $__env->endSlot(); ?>

<section class="w-full">
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <?php if(count($products)): ?>
                        <table class="w-full text-sm rounded-lg overflow-hidden">
                            <tr class="bg-black text-gray-100">
                                <th class="text-start p-2">Image</th>
                                <th class="text-start p-2">Name</th>
                                <th class="text-start p-2">Price</th>
                                <th class="text-end  p-2">Status</th>
                                <th class="text-end  p-2">Created</th>
                                <th class="text-end  p-2">LastUpdated</th>
                            </tr>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd:bg-gray-100">
                                    <td class="text-start p-2"><img src="<?php echo e(asset('/storage/'.$product->image)); ?>" alt="<?php echo e($product->name); ?> Image" width="50"></td>
                                    <td class="text-start p-2"><?php echo e($product->name); ?></td>
                                    <td class="text-start p-2">$<?php echo e($product->price); ?></td>
                                    <td class="text-end p-2">
                                        <?php if($product->is_active): ?>
                                            <span wire:click="updateStatus(<?php echo e($product->id); ?>, false)" class="bg-green-600/10 cursor-pointer rounded-full border-green-600 border p-1 font-semibold px-4 text-green-600">Active</span>
                                        <?php else: ?>
                                            <span wire:click="updateStatus(<?php echo e($product->id); ?>, true)" class="bg-red-600/10 cursor-pointer rounded-full border-red-600 border p-1 font-semibold px-4 text-red-600">InActive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end p-2"><?php echo e($product->created_at->diffForHumans()); ?></td>
                                    <td class="text-end p-2"><?php echo e($product->updated_at->diffForHumans()); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <?php if($products->hasPages()): ?>
                            <div class="p-3 bg-gray-50 rounded-lg">
                                <?php echo e($products->links()); ?>

                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="py-3 text-center">Product do not exist!</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH E:\Laravel\fountain\resources\views/livewire/products/products-listing.blade.php ENDPATH**/ ?>