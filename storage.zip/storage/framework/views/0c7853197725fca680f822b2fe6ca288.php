<section class="w-full">
    <div class="max-w-6xl m-auto py-12 px-4 w-full text-center">
        <h2 class="text-5xl title mb-4">About Trade Fountain</h2>
        <p class="text-gray-600 max-w-4xl m-auto">Trade Fountain is the ultimate solution for customers tired of low-quality kitchen towels, and napkins. We understand the value of comfort and durability, which is why our products are designed to provide long-lasting performance. We have dealt with all negative reviews and improved our products to meet the highest standards. Shop with us and experience the difference.</p>
    </div>
</section><?php /**PATH E:\Laravel\fountain\resources\views/components/about.blade.php ENDPATH**/ ?>