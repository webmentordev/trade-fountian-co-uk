<nav class="w-full top-0 left-0 bg-white sticky z-50">
    <div class="max-w-[90%] 1140:max-w-full m-auto py-3 px-4 flex items-center justify-between">
        <a href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('assets/logo.png')); ?>" width="200" alt="Trade Fountain Logo">
        </a>
        <ul class="font-semibold 940:hidden">
            <a class="mx-4 py-1 hover:text-orange-400 transition-all" href="<?php echo e(route('home')); ?>">Home</a>
            <a class="mx-4 py-1 hover:text-orange-400 transition-all" href="<?php echo e(route('products')); ?>">Products</a>
            <a class="mx-4 py-1 hover:text-orange-400 transition-all" href="<?php echo e(route('cart')); ?>">Cart</a>
        </ul>
        
        <div class="flex items-center 940:hidden">
            <ul class="font-semibold">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->is_admin): ?>
                        <a class="pr-5 py-1 hover:text-orange-400 transition-all border-r border-gray-100" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                    <?php endif; ?>
                    <a class="mx-4 pr-4 py-1 hover:text-orange-400 transition-all border-r border-gray-100" href="<?php echo e(route('client')); ?>">Client</a>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <a class="pr-5 py-1 hover:text-orange-400 transition-all border-r border-gray-100" href="<?php echo e(route('login')); ?>">Login</a>
                    <a class="mx-4 py-1 hover:text-orange-400 transition-all" href="<?php echo e(route('register')); ?>">Signup</a>
                <?php endif; ?>
            </ul>
            <a href="<?php echo e(route('cart')); ?>" class="p-2 ml-3 bg-gray-100 rounded-full flex items-center cursor-pointer">
                <img src="https://api.iconify.design/mingcute:shopping-bag-2-fill.svg?color=%232f322f" alt="Cart Icon" width="25">
            </a>
            <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-black py-2 ml-3 px-5 text-white font-semibold">Logout</button>
                </form>
            <?php endif; ?>
        </div>
        <div class="hidden 940:block p-2 ml-3 bg-gray-100 rounded-full items-center cursor-pointer relative" x-data="{ open: false }">
            <img x-on:click="open = !open" src="https://api.iconify.design/fluent:text-align-right-16-filled.svg?color=%231f1e1e" alt="Align Icon" width="25">
            <ul class="absolute w-[200px] text-start right-1 top-10 rounded-lg bg-black text-white flex flex-col bg-dark p-6 link" x-show="open" x-transition x-cloak>
                <a class="pb-3 border-b border-white/10" href="<?php echo e(route('home')); ?>">Home</a>
                <a class="py-3 border-b border-white/10" href="<?php echo e(route('products')); ?>">Products</a>
                <a class="py-3 border-b border-white/10" href="<?php echo e(route('cart')); ?>">Cart</a>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->is_admin): ?>
                        <a class="py-3 border-b border-white/10" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                    <?php endif; ?>
                    <a class="py-3 border-b border-white/10" href="<?php echo e(route('client')); ?>">Client</a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="mt-3 px-4 text-md link py-1 bg-white text-black font-semibold">Logout</button>
                    </form>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <a class="py-3 border-b border-white/10" href="<?php echo e(route('login')); ?>">Login</a>
                    <a class="py-3" href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    
</nav><?php /**PATH E:\Laravel\fountain\resources\views/livewire/navbar.blade.php ENDPATH**/ ?>