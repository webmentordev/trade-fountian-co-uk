<section class="w-full">
    <header class="py-12 px-4 w-full h-[200px] flex items-center relative justify-center bg-center bg-cover" style="background-image: url(<?php echo e(asset('assets/header-image.jpg')); ?>)">
        <div class="absolute top-0 left-0 h-full w-full bg-black/50 backdrop-blur-sm"></div>
        <h1 class="title text-4xl text-white relative z-10">Product Details / Buy Now</h1>
    </header>
    <div class="max-w-7xl py-12 relative px-4 w-full grid grid-cols-2 gap-12 980px:grid-cols-1 980px:max-w-xl m-auto" x-data="{ images: [
        <?php if(count($product->images)): ?>
            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e(asset('/storage/'. $item->url)); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    ], active: null}" x-init="active = images[0]">
        <div class="w-full">
            <div class="h-[500px] bg-gray-100 flex items-center justify-center">
                
                <img :src="active" alt="<?php echo e($product->name); ?> Image" class="w-[70%] 490px:w-[90%]">
            </div>
            <?php if(count($product->images)): ?>
                <div class="grid grid-cols-6 gap-3 py-3 w-full 490px:grid-cols-3">
                    <template x-for="image in images">
                        <img :src="image" width="150px" class="mr-2 rounded-lg h-full object-cover" :class="{ 'border-4 border-blue-300': active == image }" x-on:mouseenter="active = image">
                    </template>
                </div>
            <?php endif; ?>
        </div>
        <?php if(session('success')): ?>
            <?php if (isset($component)) { $__componentOriginal235d565c1d9da321d074440f16ad58d9 = $component; } ?>
<?php $component = App\View\Components\Alerts\Success::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alerts.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alerts\Success::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('success'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal235d565c1d9da321d074440f16ad58d9)): ?>
<?php $component = $__componentOriginal235d565c1d9da321d074440f16ad58d9; ?>
<?php unset($__componentOriginal235d565c1d9da321d074440f16ad58d9); ?>
<?php endif; ?>
        <?php endif; ?>
        <div wire:loading wire:target="add_to_cart">
            <?php if (isset($component)) { $__componentOriginal805ea0d1f903c924d84101912cbe6ca6 = $component; } ?>
<?php $component = App\View\Components\Alerts\Loading::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alerts.loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alerts\Loading::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => 'Adding to cart...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal805ea0d1f903c924d84101912cbe6ca6)): ?>
<?php $component = $__componentOriginal805ea0d1f903c924d84101912cbe6ca6; ?>
<?php unset($__componentOriginal805ea0d1f903c924d84101912cbe6ca6); ?>
<?php endif; ?>
        </div>
        <div class="w-full flex flex-col py-6">
            <h2 class="font-semibold text-3xl mb-6"><?php echo e($product->name); ?></h2>
            <?php if($quantity && $quantity > 0): ?>
                <span class="text-red-500 text-4xl font-semibold price mb-3">€<?php echo e($product->price * $quantity); ?></span>
            <?php else: ?>
                <span class="text-red-500 text-4xl font-semibold price mb-3">€<?php echo e($product->price); ?></span>
            <?php endif; ?>
            <h3 class="mb-2 text-3xl title">About This Item</h3>
            <?php echo $product->description; ?>

            <div class="flex items-center mt-6 490px:flex-col">
                <div class="w-full mb-3">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'quantity','autocomplete' => 'off','min' => '0','wire:model' => 'quantity','placeholder' => 'Quantity','class' => 'block mt-1 w-full','type' => 'number','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'quantity','autocomplete' => 'off','min' => '0','wire:model' => 'quantity','placeholder' => 'Quantity','class' => 'block mt-1 w-full','type' => 'number','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('quantity'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('quantity')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <button wire:click="add_to_cart" class="py-2 mb-3 group items-center px-4 rounded-lg text-black border border-black h-fit w-full ml-3 490px:ml-0 hover:bg-black hover:text-white transition-all">
                    <div class="flex items-center justify-center">
                        <img src="https://api.iconify.design/solar:cart-large-broken.svg?color=%23000" class="mr-2 group-hover:hidden" alt="Cart Icon" width="23">
                        <img src="https://api.iconify.design/solar:cart-large-broken.svg?color=%23fff" class="mr-2 hidden group-hover:block" alt="Cart Icon" width="23"> Add to Cart
                    </div>
                </button>
                <a href="<?php echo e(route('cart')); ?>" class="py-2 mb-3 items-center px-4 bg-black rounded-lg text-white h-fit w-full ml-3 490px:ml-0 text-center font-semibold">Checkout</a>
            </div>
            <div class="flex justify-between items-center w-full py-3 410px:flex-col">
                <img class="w-[200px]" src="<?php echo e(asset('assets/payment_cards.png')); ?>" alt="Stripe Payment Methods">
                <img class="w-[150px]" src="<?php echo e(asset('assets/stripe.png')); ?>" alt="Stripe Logo">
            </div>
        </div>
    </div>

    <div class="max-w-4xl m-auto py-12 px-4">
        <h3 class="mb-3 text-4xl font-semibold price">Product Description</h3>
        <main class="main-body">
            <?php echo $product->body; ?>

            <img src="<?php echo e(asset('assets/slides/slide_1.jpg')); ?>" class="rounded-lg shadow-lg mb-3" alt="Trade Fountain Image">
            <img src="<?php echo e(asset('assets/slides/slide_2.jpg')); ?>" class="rounded-lg shadow-lg mb-3" alt="Trade Fountain Image">
            <img src="<?php echo e(asset('assets/slides/slide_3.jpg')); ?>" class="rounded-lg shadow-lg mb-3" alt="Trade Fountain Image">
            <img src="<?php echo e(asset('assets/slides/slide_4.jpg')); ?>" class="rounded-lg shadow-lg mb-3" alt="Trade Fountain Image">
        </main>
    </div>
</section><?php /**PATH E:\Laravel\fountain\resources\views/livewire/products/single-product.blade.php ENDPATH**/ ?>